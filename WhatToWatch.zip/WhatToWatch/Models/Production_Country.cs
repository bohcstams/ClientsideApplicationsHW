﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhatToWatch.Models
{
    public class Production_Country
    {
        public string iso_3166_1 { get; set; }
        public string name { get; set; }
    }
}
